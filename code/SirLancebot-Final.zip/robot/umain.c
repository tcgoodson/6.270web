// Include headers from OS
#include "umain.h"


//.531 cm per tick

// class examples will run examples from class (code probably has bugs)
// Definitions
#define CLASS_EXAMPLES FALSE;
#define VPS_PER_FOOT 682.6666; // Amount of VPS units per foot WILL BE CHANGED IN FUTURE ROUNDS!!!
#define INT16_TO_DEGREES (360/4096);
#define DEGREES_TO_INT16 (4096/360);

// Global BAD variables
extern volatile uint8_t robot_id;

// Can hold location values.
/*
struct location
{
	int16_t x;
	int16_t y;
	int16_t theta;
};
typedef struct location Location;
*/

// VPS
/*******************************
/ position call: copy_objects();
/ objects includes:
/ signed ints(-2048, 2047): x, y, theta
/
/ (0, 0) is centerfield
/ objects[0].x
/ objects[0].y
/ objects[0].theta
/
/ goal coordinate info:
/ objects[2].x
/ objects[2].y
/
/ data timestamp access
/ position_microtime[0]
/ get_time_us() // function that returns the robots current time
*********************************/


/* Magical servo positions
	0 = 229
	DOWN =  332
	UP = 150
	CENTER = 254
*/




Location* robot; //a local copy that will point to the main location variable in vps.c
bool isBlue; //team color!
Location noTarget;
int8_t ballCount;


//coordinates of useful stuff
Point_i16 spinners[6];
Point_i16 dispensers[6];
Point_i16 outerHex[6];
Point_i16 innerHex[6];
Location territories[6];


int usetup (void) {
	//initialize ALL THE THINGS!
	robot_id = 17;
	
	gyro_init (23, 1400000, 500L);
	
	init_lock(&locationLock, "Location Lock"); //initialize the struct
	init_lock(&targetLock, "Target Lock"); //initialize the struct
		
	ballCount = 0;	
	
	noTarget.x = 0;
	noTarget.y = 0;
	
	territories[0].x = 1228*CM_PER_VPS_DIST;
	territories[0].y = 0*CM_PER_VPS_DIST;
	territories[1].x = 624*CM_PER_VPS_DIST;
	territories[1].y = 1064*CM_PER_VPS_DIST;
	territories[2].x = -624*CM_PER_VPS_DIST;
	territories[2].y = 1064*CM_PER_VPS_DIST;
	territories[3].x = -1228*CM_PER_VPS_DIST;
	territories[3].y = 0*CM_PER_VPS_DIST;
	territories[4].x = -624*CM_PER_VPS_DIST;
	territories[4].y = -1064*CM_PER_VPS_DIST;
	territories[5].x = 624*CM_PER_VPS_DIST;
	territories[5].y = -1064*CM_PER_VPS_DIST;
	
	spinners[0].x = 1791;		//B
	spinners[0].y = 443;
	spinners[1].x = 512;		//E
	spinners[1].y = 1773;
	spinners[2].x = -1280;	//H
	spinners[2].y = 1330;
	spinners[3].x = -1791;	//K
	spinners[3].y = -443;
	spinners[4].x = -512;		//N
	spinners[4].y = -1773;
	spinners[5].x = 1280;		//Q
	spinners[5].y = -1330;
	
	dispensers[0].x = 1791;	//R
	dispensers[0].y = -443;
	dispensers[1].x = 1280;	//C
	dispensers[1].y = 1330;
	dispensers[2].x = -512;	//F
	dispensers[2].y = 1773;
	dispensers[3].x = -1791;	//I
	dispensers[3].y = 443;
	dispensers[4].x = -1280;	//L
	dispensers[4].y = -1330;
	dispensers[5].x = 512;	//O
	dispensers[5].y = -1773;
	
	/*outerHex[0].x = 2047;	//A
	outerHex[0].y = 0;
	outerHex[1].x = 1024;	//D
	outerHex[1].y = 1773;
	outerHex[2].x = -1024;	//G
	outerHex[2].y = 1773;
	outerHex[3].x = -2047;	//J
	outerHex[3].y = 0;
	outerHex[4].x = -1024;	//M
	outerHex[4].y = -1773;
	outerHex[5].x = 1024;	//P
	outerHex[5].y = -1773;*/
	
	innerHex[0].x = 443;	//S
	innerHex[0].y = 256;
	
	innerHex[1].x = -222;		//T //0
	innerHex[1].y = 384;        //512
	
	innerHex[2].x = -443;	//U 
	innerHex[2].y = 256;       
	innerHex[3].x = -443;	//V
	innerHex[3].y = -256;
	
	innerHex[4].x = 222;		//W //0
	innerHex[4].y = -384;       //-512
	
	innerHex[5].x = 443;	//X
	innerHex[5].y = -256;		
    return 0;
}


/***************************************************
* umain: Entry point to contestant code
*		
* Notes: Contains the strategy and decision code
			for the robot. The high-level actions
			are controlled from here.
****************************************************/
int umain (void) {
	gyro_set_degrees(0);
	encoder_reset(24);
	
	create_thread(&vpsLoop, STACK_DEFAULT, 0, "vps_thread");
	create_thread(&navigationLoop, STACK_DEFAULT, 1, "navigation_thread");
	
	robot = getCurrentLocation();
	
	uint32_t count = 0;
	
	do{
		//digital_write(0,1);
		setColor();
	}while(robot->x == 0 && robot->y == 0 );
	
	setColor();
	
	servo_set_pos(0, ARM_SERVO_CENTER);
	
	//do a circle around the field
	explore();
	
	count = 0;
	while(1){	
		count++;
		
		if(count%30==0){
			//digital_write(0,1);
		}else if(count%15==0){
			//digital_write(0,0);
		}
		digital_write(0,0);
		
	
//	servo_set_pos(0, frob_read()/2);
//	printf("Servo: %d\n", frob_read()/2);
		capture();
		//driveStraight(60);
	
		/*	servo_set_pos(0, ARM_SERVO_DOWN);
			pause(500);
			servo_set_pos(0, ARM_SERVO_CENTER);
			pause(500);*/
		
		pause(STANDARD_PAUSE);

	}
    return 0;
}

void setColor(){	
	if(robot->x < 0){
		isBlue = false;
	}else if(robot->x > 0){
		isBlue = true;
	}
}

void goToPointProcess(Location* current, Location target, bool forward, float linearTolerance){
	setTarget(target, forward);
	
	uint32_t count = 0;
	Location prevLoc;
	bool triedBackout = false;
	
	while(!isAtPoint(*current, target, linearTolerance))	{		
		count++;
		
		if(calculateDistance(*current, prevLoc)<2){
			if(count>500){
				//freak the fuck out
				count=501;
				if(!triedBackout){
					while(count<600){
						motor_set_vel(MOTOR_LEFT, -254);
						motor_set_vel(MOTOR_LEFT, -254);
						count++;
						
						if(calculateDistance(*current, prevLoc)>=2){
							count = 0;
							break;
						}
						prevLoc = *current;
						pause(STANDARD_PAUSE); //i hope this will run often enough that the other threads won't interfere
					}
					turnBrieflyLeft();
					turnBrieflyRight();
					triedBackout = true;
				}else{
					while(count<600){
						motor_set_vel(MOTOR_LEFT, 254);
						motor_set_vel(MOTOR_LEFT, 254);
						count++;
						if(calculateDistance(*current, prevLoc)>=2){
							count = 0;
							break;
						}
					
						prevLoc = *current;
						pause(STANDARD_PAUSE); //i hope this will run often enough that the other threads won't interfere
					}
					turnBrieflyLeft();
					turnBrieflyRight();
					triedBackout = false;
				}
			}
		}else{
			count = 0;
		}
		
		prevLoc = *current;
		pause(STANDARD_PAUSE);
	}
	setTarget(noTarget, forward);
	stopDrive();
}

int min(int one, int two){
	if(one<=two)
		return one;
	else
		return two;
}

void goToFarTerritoryProcess(Location* current, Location target, bool forward, float linearTolerance){
	uint8_t endTerritory = calculateCurrentTerritory(target);
	uint8_t currentTerritory = calculateCurrentTerritory(*current);
	uint8_t difference = abs(endTerritory-currentTerritory);
	bool clockwise;
	
	if(difference > 3){
		clockwise = false;
	}else{
		clockwise = true;
	}
	
	uint8_t tN;
	
	for (tN = 0; tN <= min(difference, 3); tN++ ){
		uint8_t targetTerritory;
		
		if(clockwise){
			targetTerritory = (currentTerritory - tN) % 6;
		}else{
			targetTerritory = (currentTerritory + tN) % 6;
		}
		//digital_write(0,1);
		
		goToPointProcess(current, territories[targetTerritory], true, EXPLORE_LINEAR_TOLERANCE);
	}
}
bool captureTerritoryProcess(uint8_t targetTerritory){
	captureTerritory(isBlue);
	stopDrive();
	
	driveStraight(60);
	
	uint32_t count = 0;
	
	while(game.territories[targetTerritory].owner != robot_id){
		count++;
		driveStraight(60);
		if(count>400){
			stopDrive();
			
			return false;
		}
		
		pause(STANDARD_PAUSE);
	}
	
	stopDrive();
	
	stopCapture();
	
	return true;
}

bool collectProcess(uint8_t targetTerritory){
	
	uint8_t initBallCount = game.territories[targetTerritory].remaining;
	if(game.territories[targetTerritory].rate_limit == 0){
		while(initBallCount>0 && initBallCount - game.territories[targetTerritory].remaining < 5){
			driveStraight(-50);
		
			uint8_t prevCount = game.territories[targetTerritory].remaining;
			servo_set_pos(0, ARM_SERVO_CENTER);
			pause(300);
			servo_set_pos(0, ARM_SERVO_DOWN);
			pause(300);
			servo_set_pos(0, ARM_SERVO_CENTER);
		
			pause(250);
			//if we don't actually get a ball
			if(prevCount - game.territories[targetTerritory].remaining<1){
				stopDrive();
				
				return false;
			}
			ballCount++;
		}
	}
	stopDrive();
	
	return true;
}
void depositProcess(Location* current, Location target, bool forward, float linearTolerance){
	//goToFarTerritoryProcess(current, target, forward, linearTolerance);
	goToPointProcess(current, territories[calculateCurrentTerritory(target)], forward, linearTolerance);
	goToPointProcess(current, target, forward, SPINNER_LINEAR_TOLERANCE+7);
	
	/*servo_set_pos(0, ARM_SERVO_UP);
	pause(1500); //2300
	servo_set_pos(0, ARM_SERVO_CENTER);
	pause(500);
	servo_set_pos(0, ARM_SERVO_UP);
	pause(2300);
	servo_set_pos(0, ARM_SERVO_CENTER);*/
	
	servo_set_pos(0, ARM_SERVO_UP);
	pause(1500); //2300

	for(uint8_t sN=0;sN<4;sN++){
		servo_set_pos(0, ARM_SERVO_CENTER);
		pause(100);
		servo_set_pos(0, ARM_SERVO_UP);
		pause(100);
	}
	pause(400);
	servo_set_pos(0, ARM_SERVO_CENTER);
}


void turnBrieflyLeft(){
	motor_set_vel(MOTOR_LEFT,-200);
	motor_set_vel(MOTOR_RIGHT,200);
	pause(200);
	stopDrive();
}
void turnBrieflyRight(){
	motor_set_vel(MOTOR_LEFT,200);
	motor_set_vel(MOTOR_RIGHT,-200);
	pause(200);
	stopDrive();
}
void backupBriefly(){
	driveStraight(-200);
	pause(500);
	stopDrive();
}
void forwardBriefly(){
	driveStraight(200);
	pause(500);
	stopDrive();
}

void capture(){
	uint8_t startingTerritory = calculateCurrentTerritory(*robot);
	uint8_t tN;
	
	for (tN = 0; tN < 6; tN++ ){
		uint8_t targetTerritory = (startingTerritory + tN) % 6;
		
		goToPointProcess(robot, territories[targetTerritory], true, LINEAR_TOLERANCE);
		
		if(game.territories[targetTerritory].owner != robot_id){
			Location spinner;
			spinner.x = spinners[targetTerritory].x* CM_PER_VPS_DIST;
			spinner.y = spinners[targetTerritory].y* CM_PER_VPS_DIST;
		
			goToPointProcess(robot, spinner, true, SPINNER_LINEAR_TOLERANCE);
			
			uint8_t failCountSpin = 0;
			while(!captureTerritoryProcess(targetTerritory)){
				failCountSpin++;
				if(failCountSpin>3){
					break;
				}
				backupBriefly();
				goToPointProcess(robot, territories[targetTerritory], false, LINEAR_TOLERANCE);
				goToPointProcess(robot, spinner, true, SPINNER_LINEAR_TOLERANCE);
				
			}
			
			backupBriefly();
			goToPointProcess(robot, territories[targetTerritory], false, LINEAR_TOLERANCE);
			
			//backupBriefly();
		}
		
		Location dispenser;
		dispenser.x = dispensers[targetTerritory].x* CM_PER_VPS_DIST;
		dispenser.y = dispensers[targetTerritory].y* CM_PER_VPS_DIST;
		
		if(game.territories[targetTerritory].owner == robot_id){
			if(game.territories[targetTerritory].remaining>0){
				if(game.territories[targetTerritory].rate_limit == 0){
					//goToPointProcess(robot, territories[targetTerritory], true, LINEAR_TOLERANCE);
				
					goToPointProcess(robot, dispenser, false, SPINNER_LINEAR_TOLERANCE);
				
					uint8_t failCount = 0;
					while(!collectProcess(targetTerritory)){
						failCount++;
						if(failCount>2){
							break;
						}
						forwardBriefly();
						goToPointProcess(robot, territories[targetTerritory], true, LINEAR_TOLERANCE);
						goToPointProcess(robot, dispenser, false, LINEAR_TOLERANCE);
					}
					
					forwardBriefly();
					goToPointProcess(robot, territories[targetTerritory], true, LINEAR_TOLERANCE);
					//forwardBriefly();
				}
			}
		}
		if(ballCount>10){
			Location dumpLocation;
			
			if(isBlue){
				dumpLocation.x = innerHex[1].x * CM_PER_VPS_DIST;
				dumpLocation.y = innerHex[1].y  * CM_PER_VPS_DIST;
			}else{
				dumpLocation.x = innerHex[4].x * CM_PER_VPS_DIST;
				dumpLocation.y = innerHex[4].y * CM_PER_VPS_DIST;
			}
			depositProcess(robot, dumpLocation, true, EXPLORE_LINEAR_TOLERANCE);
			goToPointProcess(robot, territories[(calculateCurrentTerritory(dumpLocation))%6], false, EXPLORE_LINEAR_TOLERANCE);
			
		}
	}
}

void explore(){
	
	uint8_t startingTerritory = calculateStartingTerritory();
	uint8_t tN;
	
	for (tN = 1; tN < 6; tN++ ){
		uint8_t targetTerritory = (startingTerritory + tN) % 6;
		
		goToPointProcess(robot, territories[targetTerritory], true, EXPLORE_LINEAR_TOLERANCE);
		
	}
}

uint8_t calculateStartingTerritory(){
	uint8_t territory = 0;
	
	if(robot->x < 0){
		territory = 3;
		isBlue = false;
	}else if(robot->x > 0){
		territory = 0;
		isBlue = true;
	}
	
	return territory;
}

uint8_t calculateCurrentTerritory(Location current){
	uint8_t territory = 0;
	float minDistance = 10000000000;
	
	for(uint8_t tN = 0; tN<6; tN++){
		//calculate the distance to the center of the territory
		float dist = calculateDistance(current, territories[tN]);
		
		//if it's the smallest distance, set minDistance and the current territory
		if(dist<minDistance){
			minDistance = dist;
			territory = tN;
		}
	}
	
	return territory;
}


