#ifndef UTILS_H
#define UTILS_H

#include <joyos.h>

#define TAU (2*M_PI)
#define PI (M_PI)

#define DEGREES_PER_VPS_ANGLE (360.0 / 4096.0)
#define CM_PER_VPS_DIST (30.48 / 443.4)
#define FT_PER_VPS_DIST (1.0 / 443.4)

#define STANDARD_PAUSE (10)

struct location{
	float x;
	float y;
 	float theta;
};
struct point_i16{
	int16_t x;
	int16_t y;
};

typedef struct location Location;
typedef struct point_i16 Point_i16;

float modulus(float, float);

float calculateDistance(Location current, Location target);

#endif