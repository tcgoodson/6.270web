#ifndef VPS_H
#define VPS_H

#include <joyos.h>
#include "utils.h"
#include "locks.h"

int vpsLoop();
void vpsUpdate();
void setCurrentLocation(Location* current);
Location* getCurrentLocation();

#endif