#include <joyos.h>
#include "utils.h"
#include "locks.h"
#include "vps.h"
#include "driveFunctions.h"
#include <math.h>


int currentHexant(void);
int moveHexant(int nCurrentHexant);
uint8_t calculateCurrentHexant();
void explore();
void capture();
uint8_t calculateStartingTerritory();
uint8_t calculateCurrentTerritory();
void setColor();
void turnBrieflyLeft();
void turnBrieflyRight();