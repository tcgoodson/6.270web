#ifndef LOCKS_H
#define LOCKS_H

struct lock locationLock; //create the lock object
struct lock targetLock; //create the lock object

#endif