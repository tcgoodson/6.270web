#include "utils.h"

float modulus(float a, float b){
	int result = (int)( a / b );
	float mod = a - (float)( result ) * b;
}

float calculateDistance(Location current, Location target){
	float distance = sqrt( pow(current.x - target.x, 2.0) + pow(current.y - target.y, 2.0) );
	
	return distance;
}