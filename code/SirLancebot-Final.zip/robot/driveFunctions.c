#include "driveFunctions.h"

float origAngle = 0;
float sum = 0;
float prevError = 0;

Location* robot; //in centimeters and degrees
Location target;
bool goForward;
bool firstTurn;

void setTarget(Location targ, bool forward){
	target = targ;
	goForward = forward;
	firstTurn = true;
}

int navigationLoop(){
	robot = getCurrentLocation();
	
	while(1){
		//printf("Navigation\n");		
		
		if((int)target.x!=0 || (int)target.y!=0){
			goToPoint(*robot, target, goForward, LINEAR_TOLERANCE, ANGULAR_TOLERANCE);
		}
		pause(STANDARD_PAUSE);
	}
	return 0;
}

void goToPoint(Location current, Location target, bool forwardOnly, float linearTolerance, float angularTolerance){
	
	//calculate the angle that the robot should achieve to face the target point
	target.theta = calculateTargetAngle(current, target, forwardOnly); 
	
	//loop until the robot gets to the target point
	if(!isAtPoint(current, target, linearTolerance)){
		if((!isFacingAngle(current, target, angularTolerance)  && !firstTurn) || (!isFacingAngle(current, target, TIGHT_ANGULAR_TOLERANCE)  && firstTurn) ){
			//if we're not facing the target angle, turn toward it
			turnToAngle(current, target);
			digital_write(0,0);
			resetSum();
			gyro_set_degrees(0);
		}else{
			stopDrive();
			firstTurn = false;
			//if we're already facing the target angle, drive toward it
			if(forwardOnly){
				digital_write(0,1);
				//if we're only going forward, do that
				//driveStraight(254);
				driveReallyStraight(200);
			}else{
				//otherwise go backwards
				//driveStraight(-200);
				driveReallyStraight(-200);		
			}
		}
	}else{
		//stop driving, we got to the point
		stopDrive();
	}	
}

float calculateTargetAngle(Location current, Location target, bool forwardOnly){
	float targetAngle; // Theta to turn to
	float potentialAngle1 = atan2(target.y-current.y, target.x-current.x) * (180 / M_PI);
	float potentialAngle2;
	
	if(forwardOnly){
		//if the robot is only trying to face forward, it only needs to consider one angle
		targetAngle = potentialAngle1;
	}else{
		if(potentialAngle1<0){
			//calculate the +180 degree angle if targetAngle1 is negative
			 potentialAngle2 =  (int)(potentialAngle1 + 180) % 180;
		}else{
			//calculate the +180 degree angle if targetAngle1 is positive
			potentialAngle2 = -180 + (int)(potentialAngle1 + 180) % 180;
		}
		
		//start by assuming targetAngle2 is optimal
		targetAngle = potentialAngle2;
	}
	
	if(targetAngle> 180){		
		targetAngle = 180;
	}else if(targetAngle<-180){		
		targetAngle = -180;
	}
	
	return targetAngle;
}

/*******************************************************************************
* isAtPoint: checks if the robot is at the target location			
*
* input: 	Location	current				current location
*			Location	target				target location
*			float		linearTolerance		amount of allowed tolerance
*
* Notes: Works!
********************************************************************************/
bool isAtPoint(Location current, Location target, float linearTolerance){
	float distance = calculateDistance(current, target);
	
	linearTolerance = fabs(linearTolerance); //no negative tolerances! :B
	
	if(distance < linearTolerance)
		return true;
	
	return false;
}

/*******************************************************************************
* isFacingAngle: checks if the robot is facing the target angle		
*
* input: 	Location	current				current location
*			Location	target				target location
*			float		angularTolerance	amount of allowed tolerance
*
* Notes:
********************************************************************************/
bool isFacingAngle(Location current, Location target, float angularTolerance){
	float targetUpper = target.theta + angularTolerance;
	float targetLower = target.theta - angularTolerance;

	if(targetUpper > 180){
		//wrap the targetUpper into the negatives if it's too big
		targetUpper = -180 + (int)targetUpper % 180;
	}
	if(targetLower < -180){
		//wrap the targetLower into the positives if it's too small
		targetLower = 180 + (int)targetLower % 180;
	}

	if(targetUpper > targetLower){
		//the usual case where the bounds didn't cross the 180/-180 boundary
		if(current.theta < targetUpper && current.theta > targetLower){
			return true;
		}
	}else{
		//the funny case where the upperBound is actually smaller when crossing the 180/-180 boundary
		if(current.theta < targetUpper || current.theta > targetLower){
			return true;
		}
	}
	
	return false;
}

void turnToAngle(Location current, Location target){
	//set the driveSpeed based proportionally how much error is in the angle
	float driveSpeed = (target.theta-current.theta)*(200.0/180.0); ///NEEED TO FIX THE SPEED FOR WHEN IT NEEDS TO CROSS THE 180/-180 DIVIDE!!!!
	
	if(fabs(target.theta - current.theta) > 180){
		if(driveSpeed<0){
			driveSpeed = (360+(target.theta-current.theta))*(200.0/180.0);
		}else if(driveSpeed>0){
			driveSpeed = -(360-(target.theta-current.theta))*(200.0/180.0);
		}
	}
	
	if(driveSpeed < 50 && driveSpeed>=0){
		driveSpeed = 50;
	}else if(driveSpeed > -50 && driveSpeed<0){
		driveSpeed = -50;
	}
	
	//limit driveSpeed	
	if(driveSpeed>254){
		driveSpeed = 254;
	}else if(driveSpeed< -254){
		driveSpeed = -254;
	}
	
	//allow the robot to travel across the 180/-180 boundary
	int sign = 1;
	if(fabs(current.theta - target.theta) > 180){
		//sign = -1;
	}
	motor_set_vel(MOTOR_RIGHT, (int16_t)driveSpeed * sign );
	motor_set_vel(MOTOR_LEFT, -(int16_t)driveSpeed * sign );	
}

bool isFacingForwardTowardAngle(Location current, Location target, float angularTolerance){
	return true;
}


void driveMagicallyStraight(Location current, Location target, int16_t speed){
	int16_t speedLeft = speed;
	int16_t speedRight = speed;
	float multiplier = 0.1;
	
	float error = target.theta - current.theta;
	
	if(fabs(error)>180){
		if(error<0){
			error = (360 + error);
		}else if(error>0){
			error = -(360 - error);
		}
	}
	
	sum += error;
	
	float pid = PID_P*error+ PID_I*sum + PID_D 	*(error-prevError);
	pid *= multiplier;
	
	prevError = error;
	
	speedRight = speed+(int16_t)(pid/2);
	speedLeft = speed-(int16_t)(pid/2);
	
	
	if(speedRight<-254){
		speedRight = -254;
	}else if(speedRight>254){
		speedRight = 254;
	}
	if(speedLeft<-254){
		speedLeft = -254;
	}else if(speedLeft>254){
		speedLeft = 254;
	}
	motor_set_vel(MOTOR_RIGHT,speedRight);
	motor_set_vel(MOTOR_LEFT,speedLeft);
}

void driveReallyStraight (int16_t baseSpeed) {
	int16_t speedLeft = 200;
	int16_t speedRight = 200;
	
	float error = 0 - gyro_get_degrees();
	
	sum += error;
	
	float pid = PID_P*error + PID_I*sum + PID_D*(error-prevError);
			
	prevError = error;
			
//	printf("P: %f\tI: %f\tPID: %f\tLeft: %d\tRight: %d\n", PID_P*error, PID_I*sum, pid, speedLeft, speedRight);
	
	speedRight = baseSpeed+(int16_t)(pid/2);
	speedLeft = baseSpeed-(int16_t)(pid/2);
	
	if(speedRight<-254){
		speedRight = -254;
	}else if(speedRight>254){
		speedRight = 254;
	}
	if(speedLeft<-254){
		speedLeft = -254;
	}else if(speedLeft>254){
		speedLeft = 254;
	}
	
	motor_set_vel(MOTOR_RIGHT, speedRight);
	motor_set_vel(MOTOR_LEFT, speedLeft);
}

void driveStraight(int16_t speed){
	motor_set_vel(MOTOR_RIGHT, speed);
	motor_set_vel(MOTOR_LEFT, speed);	
}

/*******************************************************************************
* driveForward: drives the robot forward	
*
* input: 	Location	current		current location
*			Location	target		target location
*
* Notes:
********************************************************************************/
void driveForward(){
	motor_set_vel(MOTOR_RIGHT, 254);
	motor_set_vel(MOTOR_LEFT, 254);	
}

/*******************************************************************************
* driveBackward: drives the robot backward	
*
* input: 	Location	current		current location
*			Location	target		target location
*
* Notes:
********************************************************************************/
void driveBackward(){	
	motor_set_vel(MOTOR_RIGHT, -254);
	motor_set_vel(MOTOR_LEFT, -254);
}

/*******************************************************************************
* stopDrive: stops the drive motors		
*
* Notes:
********************************************************************************/
void stopDrive(){
	motor_set_vel(MOTOR_RIGHT, 0);
	motor_set_vel(MOTOR_LEFT, 0);
}


void captureTerritory(bool isBlue){
	if(isBlue){
		motor_set_vel(MOTOR_SPIN, BLUE_CAPTURE);
	}else{
		motor_set_vel(MOTOR_SPIN, RED_CAPTURE);
	}
}

void stopCapture(){
	motor_set_vel(MOTOR_SPIN, 0);
}

void resetSum(){
	sum = 0;
}