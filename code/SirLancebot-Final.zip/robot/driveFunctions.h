#ifndef DRIVEFUNCTIONS_H
#define DRIVEFUNCTIONS_H

#include <joyos.h>
#include <math.h>
#include "utils.h"
#include "locks.h"
#include "vps.h"

#define MOTOR_RIGHT (0)
#define MOTOR_LEFT (1)
#define MOTOR_SPIN (2)

//it's the fucking magic constants, man
#define PID_P (4.5) 
#define PID_I (0.12)
#define PID_D (0.11)

#define WHEEL_DIAMETER (1.0+11.0/16.0)
#define TICKS_PER_ROTATION (24)

#define MAX_DEGREES (180)
#define MIN_DEGREES (-180)
#define TICKS_PER_CM (305.0/574.0)
#define ANGULAR_TOLERANCE (15)		//in degrees
#define TIGHT_ANGULAR_TOLERANCE (5)		//in degrees
#define LINEAR_TOLERANCE (15)		//in centimeters
#define SPINNER_LINEAR_TOLERANCE (22)		//in centimeters
#define EXPLORE_LINEAR_TOLERANCE (30)		//in centimeters //35

#define ARM_SERVO_0  (229)
#define ARM_SERVO_DOWN  (299)
#define ARM_SERVO_UP (0)
#define ARM_SERVO_CENTER (191)

#define BLUE_CAPTURE (254)
#define RED_CAPTURE (-254)

void turnToPoint(Location current, Location target, float tolerance);

bool isFacingPoint(Location current, Location target, float tolerance);

void driveStraightMagic(Location current, Location target);

void driveBackwardMagic(Location current, Location target);

void resetSum();


void setTarget(Location, bool);

int navigationLoop();

void goToPoint(Location current, Location target, bool forwardOnly, float linearTolerance, float angularTolerance);

float calculateTargetAngle(Location current, Location target, bool forwardOnly);

bool isAtPoint(Location current, Location target, float linearTolerance);

bool isFacingAngle(Location current, Location target, float angularTolerance);

void turnToAngle(Location current, Location target);

bool isFacingForwardTowardAngle(Location current, Location target, float angularTolerance);

void driveMagicallyStraight(Location current, Location target, int16_t speed);

void driveReallyStraight ();

void driveStraight(int16_t speed);

void driveForward();

void driveBackward();

void stopDrive();

void captureTerritory(bool);

void stopCapture();



#endif