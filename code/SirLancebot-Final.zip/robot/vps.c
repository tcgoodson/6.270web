#include "vps.h"

Location currentLocation;

int vpsLoop(){
	currentLocation.x = 0;
	currentLocation.y = 0;
	currentLocation.theta = 0;
	
	while(1){
		//printf("VPS\n");
		vpsUpdate();
		
		pause(STANDARD_PAUSE);
	}
	return 0;
}

/***************************************************
* vpsUpdate: Updates data from the VPS	
*		
* Notes:	
****************************************************/
void vpsUpdate(){
	copy_objects();
	
	Location current;
	current.x = game.coords[0].x * CM_PER_VPS_DIST;
	current.y = game.coords[0].y * CM_PER_VPS_DIST;
	current.theta = game.coords[0].theta * DEGREES_PER_VPS_ANGLE;
	
	setCurrentLocation(&current);
}

void setCurrentLocation(Location* current){
	//acquire(&locationLock);
	
	currentLocation = *current;
	
	//release(&locationLock);
}

Location* getCurrentLocation(){
	
	return &currentLocation;
} 