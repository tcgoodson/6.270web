// Include headers from OS
#include <joyos.h>

//it's the fucking magic constants, man
#define PID_P (4.5) 
#define PID_I (0.12)
#define PID_D (0.11)

// usetup is called during the calibration period. 
int usetup (void) {
	//initialize ALL THE THINGS!
	gyro_init (23, 1400000, 500L);
	
    return 0;
}


// Entry point to contestant code.
int umain (void) {
	uint16_t count = 0;
	int16_t speedLeft = 200;
	int16_t speedRight = 200;
	float sum = 0;
	float prevError = 0;
	int16_t baseSpeed = 0;
	
    // YOUR CODE GOES HERE

	gyro_set_degrees(0);
	
	pause(500);
	
	while(1) {
		if(stop_press()) {
			go_click();
		}
		
		if(baseSpeed<200){
			baseSpeed+=1;
		}
		float error = 0 - gyro_get_degrees();
		
		sum += error;
		
		float pid = PID_P*error + PID_I*sum + PID_D*(error-prevError);
				
		prevError = error;
				
		printf("P: %f\tI: %f\tPID: %f\tLeft: %d\tRight: %d\n", PID_P*error, PID_I*sum, pid, speedLeft, speedRight);
		
		speedRight = baseSpeed+(int16_t)(pid/2);
		speedLeft = baseSpeed-(int16_t)(pid/2);
		
		if(speedRight<-254){
			speedRight = -254;
		}else if(speedRight>254){
			speedRight = 254;
		}
		if(speedLeft<-254){
			speedLeft = -254;
		}else if(speedLeft>254){
			speedLeft = 254;
		}
		
		motor_set_vel(0, speedRight);
		motor_set_vel(1, speedLeft);
		
		
	/*	printf("%d\n",frob_read()/2-255);
		
		int16_t speed = (int16_t)frob_read()/2-255;
		
		if(speed<-254){
			speed = -254;
		}else if(speed>254){
			speed = 254;
		}
		
		motor_set_vel(0,speed);
		motor_set_vel(1,speed);*/
		
		
		
		count++;
		pause(10);
	}
    // Will never return, but the compiler complains without a return
    // statement.
    return 0;
}

